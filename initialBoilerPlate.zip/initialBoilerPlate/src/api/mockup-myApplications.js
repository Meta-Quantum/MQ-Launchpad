const applicationsData = [
    {
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
{
    name: 'Project Name',
    saleDate: 'Sale Date',
    status: "Status",
},
]

export default applicationsData;