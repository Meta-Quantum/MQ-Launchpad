const tableData  = [
{
    initialCoin:'M',
    projectName: 'MTG',
    projectCoin: 'MTG',
    SHO:300000,
    allTimeHigh: 'N/A',
    lead:'Dao Maker',
    marketMakers:'-',
    type: 'Dao Incubation',
},
{

    initialCoin:'P',
    projectName: 'PRIMAL',
    projectCoin: 'PRIMAL',
    SHO:1150000,
    allTimeHigh: '8.9x',
    lead:'Step App',
    marketMakers:'Karion Labs',
    type: 'DAO Incubation',
},
{

    initialCoin:'A',
    projectName: 'Atlas Navi',
    projectCoin:'NAVI',
    SHO: 150000,
    allTimeHigh: '2.62x',
    lead: '-',
    marketMakers: 'Acheron Trading',
    type: 'Zero Cost SHO',
},
{

    initialCoin:'D',
    projectName: 'DeRaco NFT',
    projectCoin: 'DERC',
    SHO: 0,
    allTimeHigh: 'N/A',
    lead: '-',
    marketMakers: '-',
    type: 'Standard',
},
{

    initialCoin:'B',
    projectName: 'beFITTER',
    projectCoin: 'FIU',
    SHO:600000,
    allTimeHigh:'14.52x',
    lead:'Icetea Labs',
    marketMakers:'-',
    type:'Standard',
}
]

export default tableData;