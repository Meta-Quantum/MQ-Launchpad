import React from 'react'
import './Cards.scss'

function Cards() {
  return (
    <div className='cards__container'>
        <div className='cards__container__element'></div>
        <div className='cards__container__element'></div>
        <div className='cards__container__element'></div>
        <div className='cards__container__element'></div>
    </div>
  )
}

export default Cards